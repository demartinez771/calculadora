package com.example.operaciones

import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.operaciones.databinding.ActivityResultadoBinding

class Resultado : AppCompatActivity() {

    companion object {
        const val RESULTAD_KEY = "resul"
        const val BITMAP_KEY = "bitmap"
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        val binding = ActivityResultadoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle= intent.extras!!
        val bitmap = bundle.getParcelable<Bitmap>(BITMAP_KEY)
        val resul = bundle.getParcelable<CArea>(RESULTAD_KEY)!!

        binding.resultado2 = resul
        binding.imagen.setImageBitmap(bitmap)
    }
}