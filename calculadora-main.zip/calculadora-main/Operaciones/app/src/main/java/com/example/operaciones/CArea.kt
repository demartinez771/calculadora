package com.example.operaciones

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class CArea(val ancho:String,val alto: String, val arearesul : String) : Parcelable