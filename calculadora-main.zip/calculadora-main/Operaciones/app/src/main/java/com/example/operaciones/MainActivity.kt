package com.example.operaciones

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import java.lang.Exception
import java.text.DecimalFormat
import java.time.temporal.Temporal

class MainActivity : AppCompatActivity() {

    var op_actual= ""
    var primer_numero:Double=Double.NaN
    var segundo_numero:Double=Double.NaN

    lateinit var txt_temp: TextView
    lateinit var txt_result: TextView

    lateinit var format_decimal: DecimalFormat



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        format_decimal=DecimalFormat("#.############")
        txt_temp=findViewById(R.id.txt_temp)
        txt_result=findViewById(R.id.txt_result)
        area()

    }

    fun area(){
        val btn=findViewById<Button>(R.id.btn_calcular)
        btn.setOnClickListener{
            val intent=Intent(this,Area::class.java)
            startActivity(intent)
        }
    }



    fun cambiar_op(b:View){
        if(txt_temp.text.isNotEmpty() || primer_numero.toString()!="NaN"){
        calcular()
        val btn:Button=b as Button
        if(btn.text.toString().trim()=="/"){
            op_actual = "/"
        }else if(btn.text.toString().trim()=="X"){
            op_actual = "*"
        }else{
            op_actual=btn.text.toString().trim()
        }
        txt_result.text= format_decimal.format(primer_numero)+op_actual
        txt_temp.text =""
        }
    }

    fun borrar(b: View){
        val btn:Button=b as Button
        if(btn.text.toString().trim()=="C"){
            if(txt_temp.text.toString().isNotEmpty()){
                var datos_actuales:CharSequence=txt_temp.text as CharSequence
                txt_temp.text=datos_actuales.subSequence(0,datos_actuales.length-1)
            }else{
                primer_numero=Double.NaN
                segundo_numero=Double.NaN
                txt_temp.text= ""
                txt_result.text=""
            }
        }
        else if(btn.text.toString().trim()=="AC"){
            primer_numero=Double.NaN
            segundo_numero=Double.NaN
            txt_temp.text= ""
            txt_result.text=""
        }
    }



    fun calcular(){
        try{
            if(primer_numero.toString()!="NaN"){
                if(txt_temp.text.toString().isEmpty()){
                    txt_temp.text= txt_result.text.toString()

                }
                segundo_numero = txt_temp.text.toString().toDouble()
                txt_result.text=""
                when(op_actual){
                    "+"-> primer_numero=(primer_numero+segundo_numero)
                    "-"-> primer_numero=(primer_numero-segundo_numero)
                    "/"-> primer_numero=(primer_numero/segundo_numero)
                    "*"-> primer_numero=(primer_numero*segundo_numero)
                }
            }else{
                primer_numero = txt_temp.text.toString().toDouble()
            }
        }catch (e: Exception){

        }

    }
    fun seleccionarNumero(b: View){
        val btn:Button= b as Button
        txt_temp.text=txt_temp.text.toString() + btn.text.toString()
    }
    fun igual(b: View){
        calcular()
        txt_result.text= format_decimal.format(primer_numero)
        op_actual=""
    }
}