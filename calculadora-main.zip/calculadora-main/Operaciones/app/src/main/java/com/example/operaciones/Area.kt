package com.example.operaciones

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.drawable.toBitmap
import com.example.operaciones.databinding.ActivityAreaBinding


class Area : AppCompatActivity() {

    private lateinit var foto : ImageView
    private var ImgBitmap : Bitmap? = null
    var getContent = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) {
            bitmap -> ImgBitmap = bitmap
        foto.setImageBitmap(ImgBitmap!!)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val binding= ActivityAreaBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.Calcular.setOnClickListener{
            val strAlto = binding.textoAlto.text.toString()
            val strAncho = binding.textoAncho.text.toString()

            if (strAlto.isNotEmpty() && strAncho.isNotEmpty()) {
                val width = strAncho.toDouble()
                val height = strAlto.toDouble()

                val area = width * height

                val result = "Área: $area metros cuadrados"
                val mostrar = CArea(strAncho,strAlto,result)
                abre(mostrar)
            } else {
                val result = "Datos incorrectos"
                val mostrar = CArea(strAncho,strAlto,result)
                abre(mostrar)
            }

        }
        foto = binding.foto
        foto.setOnClickListener {
            openCamera()
        }


        }

    private fun openCamera() {

        getContent.launch(null)
    }

    fun abre(a:CArea){
        val intent = Intent(this,Resultado::class.java)
        intent.putExtra(Resultado.RESULTAD_KEY,a)
        intent.putExtra(Resultado.BITMAP_KEY,foto.drawable.toBitmap())
        startActivity(intent)
    }

    }








